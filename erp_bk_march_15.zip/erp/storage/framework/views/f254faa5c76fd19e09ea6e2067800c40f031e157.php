
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Expenses Create</h3>
                    <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Expences list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('expenses.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body" style="background-color:#F7F7F7">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-12">
                            <div class="form-group">
                                <label for="">Expenses Name</label>
                                <input type="text" class="form-control" name="expenses_name" placeholder="Write Expense Name"/>
                                <?php if($errors->has('expenses_name')): ?>
                                <p class="text-danger"><?php echo e($errors->first('expenses_name')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="">Expenses Amount</label>
                                <input type="text" class="form-control" name="expenses_amount" placeholder="Enter Amount"/>
                                <?php if($errors->has('expenses_amount')): ?>
                                <p class="text-danger"><?php echo e($errors->first('expenses_amount')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="">Expenses Date</label>
                                <input type="date" class="form-control" name="expenses_date" value="<?php echo e(date('Y-m-d')); ?>"/>
                                <?php if($errors->has('expenses_date')): ?>
                                <p class="text-danger"><?php echo e($errors->first('expenses_date')); ?> </p>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label>Expenses Category</label>
                                <select class="form-control" name="expenses_category">
                                    <option selected disabled>--Select Category--</option>
                                    <?php $__currentLoopData = $expensesCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->expenses_cat_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('expenses_category')): ?>
                                <p class="text-danger"><?php echo e($errors->first('expenses_category')); ?> </p>
                                <?php endif; ?>
                            </div> 
                            <div class="form-group">
                                <label>Customer ID</label>
                                <select class="form-control" name="cust_id">
                                    <option selected disabled>--Select Customer--</option>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('cust_id')): ?>
                                <p class="text-danger"><?php echo e($errors->first('cust_id')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Payment Mode</label>
                                <select class="form-control" name="pay_mode">
                                    <option selected disabled>--Select Payment--</option>
                                    <?php $__currentLoopData = $paymentMode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->pay_mode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('pay_mode')): ?>
                                <p class="text-danger"><?php echo e($errors->first('pay_mode')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="">Payment Tax</label>
                                <input type="number" class="form-control" name="pay_tax"/>
                                <?php if($errors->has('pay_tax')): ?>
                                <p class="text-danger"><?php echo e($errors->first('pay_tax')); ?> </p>
                                <?php endif; ?>
                            </div>  

                        </div>
                        
                    </div>

                     <button type="submit" class="btn btn-primary">Submit</button>
                </div>          
                    
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/expenses/create.blade.php ENDPATH**/ ?>