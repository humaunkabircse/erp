
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-8 col-md-8 offset-md-2 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Adjustment Edit</h3>
                    <a href="<?php echo e(route('collection.adjustment.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i>Adjustment list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('collection.adjustment.update',$collectionAdjustment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body" style="background-color:#F7F7F7">

                    <div class="form-group row">
                    <?php
                    $collection_id = \App\Models\CollectionAdjustment::latest()->first();
                    if($collection_id){
                        $collection_number = 'COL-ADJ-'.'0'.$collection_id->id+1;
                    }else{
                        $collection_number = 'COL-ADJ-'.'01';
                    }
                    
                    ?>
                        <label for="staticName" class="col-md-4 col-form-label">Collection Number</label>
                        <div class="col-md-8">
                            <input type="text" id="staticName" class="form-control form-control-sm" name="collection_adjustment_number"  value="<?php echo e($collectionAdjustment->collection_adjustment_number); ?>" readonly />
                        </div>


                    </div>
                    <div class="form-group row">

                        <label for="staticName" class="col-md-4 col-form-label">Customer Name</label>
                        <div class="col-md-8">
                            <select id="staticName" class="form-control form-control-sm" name="cus_id" required>
                                <option selected disabled>Select Customer</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>" <?php echo e($collectionAdjustment->cus_id==$customer->id ?'selected':''); ?>><?php echo e($customer->cus_company); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('cus_id')): ?>
                            <p class="text-danger"><?php echo e($errors->first('cus_id')); ?> </p>
                            <?php endif; ?>
                        </div>


                    </div>
                    <div class="form-group row">

                        <label for="staticName" class="col-md-4 col-form-label">Adjustment Date</label>
                        <div class="col-md-8">
                            <input type="date" id="staticName" class="form-control form-control-sm" name="collection_adjustment_date" value="<?php echo e($collectionAdjustment->collection_adjustment_date); ?>" required />

                            <?php if($errors->has('collection_adjustment_date')): ?>
                            <p class="text-danger"><?php echo e($errors->first('collection_adjustment_date')); ?> </p>
                            <?php endif; ?>
                        </div>


                        </div>


                    <div class="form-group row">
                        <label for="adjustmentAmount" class="col-md-4 col-form-label">Adjustment Amount</label>
                        <div class="col-md-8">
                            <input type="text" id="adjustmentAmount" class="form-control form-control-sm" name="collection_adjustment_amount" value="<?php echo e($collectionAdjustment->collection_adjustment_amount); ?>" required />
                            <?php if($errors->has('collection_adjustment_amount')): ?>
                            <p class="text-danger"><?php echo e($errors->first('collection_adjustment_amount')); ?> </p>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="form-group row">
                        <label for="staticShortName" class="col-md-4 col-form-label">Adjustment Purpose</label>
                        <div class="col-md-8">
                            <textarea  class="form-control form-control-sm" type="text" name="collection_adjustment_purpose" rows="3">
                            <?php echo e($collectionAdjustment->collection_adjustment_purpose); ?>

                            </textarea>
                        </div>

                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Update</button>
                </div>

        </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/collection-adjustment/edit.blade.php ENDPATH**/ ?>