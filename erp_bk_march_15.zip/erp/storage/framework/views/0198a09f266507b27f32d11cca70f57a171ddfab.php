
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Agent Create</h3>
                    <a href="<?php echo e(route('agent.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i>Agent list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('agent.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Agent Name</label>
                            <input type="text" class="form-control form-control-sm" name="agent_fullname"/>
                            <?php if($errors->has('agent_fullname')): ?>
                            <p class="text-danger"><?php echo e($errors->first('agent_fullname')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Agent Address</label>
                            <textarea type="text" rows="5" class="form-control form-control-sm" name="agent_address">
                            </textarea>
                            <?php if($errors->has('agent_address')): ?>
                            <p class="text-danger"><?php echo e($errors->first('agent_address')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Agent Contact</label>
                            <input type="text" class="form-control form-control-sm" name="agent_contact"/>
                            <?php if($errors->has('agent_contact')): ?>
                            <p class="text-danger"><?php echo e($errors->first('agent_contact')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Agent Email</label>
                            <input type="text" class="form-control form-control-sm" name="agent_email"/>
                            <?php if($errors->has('agent_email')): ?>
                            <p class="text-danger"><?php echo e($errors->first('agent_email')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                     <div class="row">
                     <div class="col-lg-12 col-md-12 col-12">
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control" name="status">
                                    <option value="active" <?php echo e(old('status')=='active'?'selected' : ''); ?>>
                                        Active</option>
                                    <option value="inactive" <?php echo e(old('status')=='inactive'?'selected' : ''); ?>>
                                        Inactive
                                    </option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                <p class="text-danger"><?php echo e($errors->first('status')); ?> </p>
                                <?php endif; ?>
                            </div>                            
                        </div>
                     </div>
                     <button type="submit" class="btn btn-primary">Submit</button>
                    </div>          
                    
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/agent/create.blade.php ENDPATH**/ ?>