
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Asset Register</h3>
                    <a href="<?php echo e(route('asset.register.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Asset Register list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('asset.register.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Asset Name</label>
                                <input type="text" name="asset_name" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('asset_name')); ?>" placeholder="Enter Name">
                                <?php if($errors->has('asset_name')): ?>
                                <p class="text-danger"><?php echo e($errors->first('asset_name')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                        <div class="form-group">
                                <label for="exampleInputEmail1">Asset Type</label>
                                <select class="form-control" name="asset_type">
                                    <option selected disabled>Select Type</option>
                                    <?php $__currentLoopData = \App\Models\AssetType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->asset_type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('asset_type')): ?>
                                <p class="text-danger"><?php echo e($errors->first('asset_type')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Purchase Date</label>
                                <input type="date" name="asset_purshase_date" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('asset_purshase_date')); ?>" placeholder="Enter purshase date">
                                <?php if($errors->has('asset_purshase_date')): ?>
                                <p class="text-danger"><?php echo e($errors->first('asset_purshase_date')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-12">
                            <div class="form-group">
                                <label for="description">Asset Note</label>
                                <textarea id="summernote" class="summernote" name="asset_note" placeholder="Write note hare..">
                                <?php echo e(old('asset_note')); ?>

                                </textarea>
                                <?php if($errors->has('asset_note')): ?>
                                <p class="text-danger"><?php echo e($errors->first('asset_note')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Asset Origin</label>
                                <input type="text" name="asset_origin" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('asset_origin')); ?>" placeholder="Write origin here..">
                                <?php if($errors->has('asset_origin')): ?>
                                <p class="text-danger"><?php echo e($errors->first('asset_origin')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Asset Price</label>
                                <input type="number" name="asset_price" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('asset_price')); ?>" placeholder="Enter Price">
                                <?php if($errors->has('asset_price')): ?>
                                <p class="text-danger"><?php echo e($errors->first('asset_price')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control" name="status">
                                    <option value="active" <?php echo e(old('status')=='active'?'selected' : ''); ?>>
                                        Active</option>
                                    <option value="inactive" <?php echo e(old('status')=='inactive'?'selected' : ''); ?>>
                                        Inactive
                                    </option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                <p class="text-danger"><?php echo e($errors->first('status')); ?> </p>
                                <?php endif; ?>
                            </div>                            
                        </div>
                    </div>          
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#summernote').summernote({
            height: 100,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/asset-register/create.blade.php ENDPATH**/ ?>