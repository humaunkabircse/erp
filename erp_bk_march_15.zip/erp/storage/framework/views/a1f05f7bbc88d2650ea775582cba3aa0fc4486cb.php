<?php $__env->startSection('style'); ?>

<style>
.report-item{
    height:80px;
    width:200px;
    background-color:red;
    padding-top:30px;
    text-align: center;
    font-size:18px;
}
.report-item a{ 
    color:#fff
}
</style>
 <!-- DataTables -->
 <link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('received.report')); ?>">Received Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('challan.report')); ?>">Challan Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('gatepass.report')); ?>">Gate Pass Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('payment.report')); ?>">Payment Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('expenses.report')); ?>">Expenses Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('collection.report')); ?>">Collection Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
            <a href="<?php echo e(route('production.report')); ?>">Production Report</a> 
            </div>        
        </div>
        <div class="col-lg-3 col-md-3 col-12 mb-3">
            <div class="report-item bg-primary">
                <a href="<?php echo e(route('stock.report')); ?>">Stock Report</a> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable({
      scrollY:     370,
      scrollX:     true,
      scroller:    true,
    });
} );
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/reports/index.blade.php ENDPATH**/ ?>