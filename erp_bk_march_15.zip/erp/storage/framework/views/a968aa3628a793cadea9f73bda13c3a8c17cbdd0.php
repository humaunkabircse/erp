
<?php $__env->startSection('style'); ?>
 <!-- DataTables -->
 <link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Term</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('term.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
      <div class="modal-body">
        <div class="form-group mb-3">
            <label for="">Term Name</label>
            <input type="text" class="form-control" name="term_name"/>
        </div>
        <div class="form-group mb-3">
            <label for="">Term Description</label>
            <input type="text" class="form-control" name="term_desc"/>
        </div>
        <div class="form-group">
            <label>Status</label>
            <select class="form-control" name="status">
                <option value="active" <?php echo e(old('status')=='active'?'selected' : ''); ?>>
                    Active</option>
                <option value="inactive" <?php echo e(old('status')=='inactive'?'selected' : ''); ?>>
                    Inactive
                </option>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!--End Add Student Modal -->
<!--Edit Student Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Term Data</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(url('update-term')); ?>" Method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <input type="hidden" name="term_id" id="term_id" />
      <div class="modal-body">
        <div class="form-group mb-3">
            <label for="">Term Name</label>
            <input type="text" class="form-control" id="term_name" name="term_name"/>
        </div>
        <div class="form-group mb-3">
            <label for="">Term Description</label>
            <input type="text" class="form-control" id="term_desc" name="term_desc"/>
        </div>
        <div class="form-group">
            <label for="">Status</label>
            <select class="form-control" id="status" name="status">
                <option value="active"> Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!--End Edit Student Modal -->
<!--Delete Student Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Student Data</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(url('delete-term')); ?>" Method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <input type="hidden" name="delete_term_id" id="deleting_term_id" />
          <p class="text-center pt-3">Are you sure to delete data?</p>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
        <button type="submit" class="btn btn-danger">Yes Delete</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!--End Delete Student Modal -->
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
            <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show myalert" role="alert">
            <strong>Success!</strong> <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>       
        <?php endif; ?>
            <div class="card-header d-flex justify-content-between">
                    <h4>Term List</h4>
                    <button type="button" class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#exampleModal" ><i class="fas fa-plus-circle"></i> Add Term</button>
                    
                </div>
                <div class="card-body">
                <table id="myTable" class="display table-bordered table-striped text-center" style="border-color:white;font-size:12px;" width="100%">
                        <thead>
                            <tr style="background:#395697;color:#fff;font-size:12px;">
                                <th>SL#</th>
                                <th>Term Name</th>
                                <th>Term Description</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
						          <tbody> 
                        <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->term_name); ?></td>
                                <td><?php echo e($item->term_desc); ?></td>
                                <td>
                                <?php if($item->status == 'active'): ?>
                                <span class="badge badge-success p-1"><?php echo e($item->status); ?></span>
                                <?php else: ?>
                                <span class="badge badge-warning p-1"><?php echo e($item->status); ?></span>
                                <?php endif; ?>
                                </td>
                                <td>
                                <button type="button" value="<?php echo e($item->id); ?>" class="btn btn-outline-primary btn-sm editbtn"><i class="fas fa-edit"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                       </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable({
      scrollY:     370,
      scrollX:     true,
      scroller:    true,
    });
} );
</script>
<script type="text/javascript">
    $(document).ready(function(){
        setTimeout(function() {
            $('.myalert').fadeOut('fast');
        }, 2000);
    });
</script>


<script>            
    $(document).on('click','.editbtn',function(){
        var term_id = $(this).val();
       $('#editModal').modal('show');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });     
       $.ajax({
            type:"GET",
            url:"edit-term/"+term_id,
            dataType: "json",
            success:function(response){
                $('#term_name').val(response.term.term_name);
                $('#term_desc').val(response.term.term_desc);
                $('#status').val(response.term.status);
                $('#term_id').val(term_id);
            }
       });

    });    
</script>
<script>
    $(document).on('click','.dltbtn',function(){
        var term_id = $(this).val();
    $('#deleteModal').modal('show');
    $('#deleting_term_id').val(term_id);
    $.ajax({
            type:"GET",
            url:"delete-term/",
            dataType: "json",
            success:function(response){
               
            }
       });   
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/term/index.blade.php ENDPATH**/ ?>