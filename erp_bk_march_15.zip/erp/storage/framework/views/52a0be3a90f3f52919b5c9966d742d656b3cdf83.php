<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
    <div class="col-lg-6 col-md-6 col-12 offset-md-3">
    <h4>Select Product For Production</h4>
        <form action="<?php echo e(route('product.search')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                    <select class="form-control select2" name="item_id" id="item_id">
                        <option selected disabled>Select Item</option>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>">
                            <?php echo e($item->item_name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </select>
                    
                   
            </div>
            <div>
                <?php if($errors->has('item_id')): ?>
                <p class="text-danger"><?php echo e($errors->first('item_id')); ?> </p>
                <?php endif; ?>   
            </div>
            <button type="submit" class="btn btn-outline-primary mt-2">Next Step</button>
            <a href="<?php echo e(route('production.master.index')); ?>" class="btn btn-outline-primary mt-2">Go Back </a>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/select2/css/select2.min.css">
<script src="<?php echo e(asset('backend')); ?>/plugins/select2/js/select2.min.js"></script>


<script type="text/javascript">
    $(".select2").select2();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/production-master/productSearch.blade.php ENDPATH**/ ?>