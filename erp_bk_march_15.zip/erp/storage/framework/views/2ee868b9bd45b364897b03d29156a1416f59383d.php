
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Error!</strong> <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>       
        <?php endif; ?>
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Vendor Payment Edit</h3>
                    <a href="<?php echo e(route('vendor.payment.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Vendor Payment list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('vendor.payment.update',$vendorPayment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body" style="background-color:#F7F7F7">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <div class="form-group">
                                <label>Vendor Name</label>
                                <select class="form-control" name="vendor_id">
                                    <option selected disabled>--Select Vendor--</option>
                                    <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>"<?php echo e($vendorPayment->vendor_id==$vendor->id?'selected':''); ?>><?php echo e($vendor->vendor_company); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('vendor_id')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_id')); ?> </p>
                                <?php endif; ?>
                            </div>                        
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <div class="form-group">
                                <label>Payment Mode</label>
                                <select class="form-control" name="pay_mode">
                                    <option selected disabled>--Select Payment Mode--</option>
                                    <?php $__currentLoopData = $paymentMode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pmode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($pmode->id); ?>"<?php echo e($vendorPayment->pay_mode==$pmode->id?'selected':''); ?>><?php echo e($pmode->pay_mode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('pay_mode')): ?>
                                <p class="text-danger"><?php echo e($errors->first('pay_mode')); ?> </p>
                                <?php endif; ?>
                            </div>                        
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Check Number</label>
                            <input type="text" class="form-control form-control-sm" name="cheque_no" value="<?php echo e($vendorPayment->cheque_no); ?>"/>
                            <?php if($errors->has('cheque_no')): ?>
                            <p class="text-danger"><?php echo e($errors->first('cheque_no')); ?> </p>
                            <?php endif; ?>
                        </div>    
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Check Date</label>
                            <input type="date" class="form-control form-control-sm" name="cheque_date" value="<?php echo e($vendorPayment->cheque_date); ?>" />
                            <?php if($errors->has('cheque_date')): ?>
                            <p class="text-danger"><?php echo e($errors->first('cheque_date')); ?> </p>
                            <?php endif; ?>
                        </div>    
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <div class="form-group">
                                <label>Bank Name</label>
                                <select class="form-control" name="bank_name_id">
                                    <option selected disabled>--Select Bank Name--</option>
                                    <?php $__currentLoopData = $bankName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bank->id); ?>"<?php echo e($vendorPayment->bank_name_id==$bank->id?'selected':''); ?>><?php echo e($bank->bank_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('bank_name_id')): ?>
                                <p class="text-danger"><?php echo e($errors->first('bank_name_id')); ?> </p>
                                <?php endif; ?>
                            </div>                        
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Payment Date</label>
                            <input type="date" class="form-control form-control-sm" name="pay_date" value="<?php echo e($vendorPayment->pay_date); ?>"/>
                            <?php if($errors->has('pay_date')): ?>
                            <p class="text-danger"><?php echo e($errors->first('pay_date')); ?> </p>
                            <?php endif; ?>
                        </div>    
                    </div>

                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Payment Amount</label>
                            <input type="number" class="form-control form-control-sm" name="pay_amount" value="<?php echo e($vendorPayment->pay_amount); ?>"/>
                            <?php if($errors->has('pay_amount')): ?>
                            <p class="text-danger"><?php echo e($errors->first('pay_amount')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                      
                            <div class="form-group">
                                <label for="">Payment Note</label>
                                <textarea rows="5" name="pay_note" class="form-control form-control-sm"  placeholder="Write note hare..">
                                <?php echo e($vendorPayment->pay_note); ?>

                                </textarea>
                                <?php if($errors->has('pay_note')): ?>
                                <p class="text-danger"><?php echo e($errors->first('pay_note')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                     <button type="submit" class="btn btn-primary">Update Payment</button>
                    </div>          
                    
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/vendor-payment/edit.blade.php ENDPATH**/ ?>