<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>-->
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
       
    <title>Collection</title>
    <style>
        .signature{
            margin-top:130px;
            display:flex;
        }
        .signature .item-1{
        margin-right:70px
        }
        .signature .item-2{
        margin-right:70px
        }
        .signature .item-3{
        margin-right:70px
        }
        .invoice{
            text-align:center;
            font-size:26px;
        }
        .in_word{
            margin-top:30px;
        }


    </style>
</head>
<body>
<!-- DataTables -->
<!-- <link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css"> -->

<div class="container">

  <div class="row">
    <div class="col-lg-12 col-md-12 col-12">    
      <div class="card">
        <div class="card-header">
          <h4>Payment Report</h4>
          <p>
          Date:
          <?php $__currentLoopData = $dateRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e(date('d/m/Y', strtotime($date))); ?>

          <?php if( ! $loop->last): ?>- <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </p>
        </div>
        <div class="card-body">
          <table class="display table-bordered table-striped text-center" style="border-color:white;font-size:12px;" width="100%">
            <thead>
              <tr style="background:#395697;color:#fff;font-size:11px;">
                <th style="text-align:center">SL#</th>
                <th style="text-align:center">Date</th>
                <th style="text-align:center">Vendor Name</th>
                <th style="text-align:center">Cheque No</th>
                <th style="text-align:center">Payment Mode</th>
                <th style="text-align:center">Amount</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $paymentDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e(date('d-m-Y', strtotime($item->pay_date))); ?></td>
                <td><?php echo e($item->vendor_name); ?></td>
                <td><?php echo e($item->cheque_no); ?></td>
                <td><?php echo e($item->pay_mode); ?></td>
                <td><?php echo e($item->pay_amount); ?></td>
              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </tbody>
          </table>
        </div>
      </div>



    </div>
  </div>
</div>
<!-- 
<script src="<?php echo e(asset('backend/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script> -->
<!-- <script type="text/javascript">
  $(document).ready(function() {
    $('#myTable').DataTable({
      scrollY: 370,
      scrollX: true,
      scroller: true,
    });
  });
</script> -->
<!--Select2 support-->
<!-- <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/select2/css/select2.min.css">
<script src="<?php echo e(asset('backend')); ?>/plugins/select2/js/select2.min.js"></script> -->
<script src="<?php echo e(asset('backend')); ?>/assets/js/jquery.printPage.js"></script>  
<!--Select2 cdn support-->
<!-- <script type="text/javascript">
  $(".select2").select2();
</script> -->

</body>

</html><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/reports/payment/payment-print.blade.php ENDPATH**/ ?>