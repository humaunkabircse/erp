
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Vendor Create</h3>
                    <a href="<?php echo e(route('vendor.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Vendor list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('vendor.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Vendor Name</label>
                                <input type="text" name="vendor_name" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('vendor_name')); ?>" placeholder="Enter Name">
                                <?php if($errors->has('vendor_name')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_name')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Company Name</label>
                                <input type="text" name="vendor_company" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('vendor_company')); ?>" placeholder="Company Name">
                                <?php if($errors->has('vendor_company')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_company')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">website <span style="color:#0069D9;font-size:12px">(Optional)</span></label>
                                <input type="text" name="vendor_website" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('vendor_website')); ?>" placeholder="Enter website">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-12">
                            <div class="form-group">
                                <label for="description">Description <span style="color:#0069D9;font-size:12px">(Optional)</span></label>
                                <textarea id="vendor_description" class="summernote" name="vendor_description" placeholder="Write description hare..">
                                <?php echo e(old('vendor_description')); ?>

                                </textarea>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Contact Number</label>
                                <input type="text" name="vendor_contact_number" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('vendor_contact_number')); ?>" placeholder="Write Contact number">
                                <?php if($errors->has('vendor_contact_number')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_contact_number')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email <span style="color:#0069D9;font-size:12px">(Optional)</span></label>
                                <input type="text" name="email" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('email')); ?>" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Vat Number  <span style="color:#0069D9;font-size:12px">(Optional)</span></label>
                                <input type="text" name="vendor_vat_number" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e(old('vendor_vat_number')); ?>" placeholder="Enter Vat Number">
                            </div>
                        </div>

                    </div>
                    <h5>Vendor Info:</h5>
                    <hr />
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="country">Country</label>
                                <input type="text" name="vendor_country" class="form-control form-control-sm" id="vendor_country" placeholder="Country Name">
                                <?php if($errors->has('vendor_country')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_country')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="district">District</label>
                                <input type="text" name="vendor_district" class="form-control form-control-sm" id="vendor_district" placeholder="District Name">
                                <?php if($errors->has('vendor_district')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_district')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="zip">Zip</label>
                                <input type="text" name="vendor_zip" class="form-control form-control-sm" id="vendor_zip" placeholder="Enter zip code">
                                <?php if($errors->has('vendor_zip')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_zip')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-12">
                            <div class="form-group">
                                <label for="street">Street</label>
                                <input type="text" id="vendor_street" name="vendor_street" class="form-control"  placeholder="Street name write here..">
                                <?php if($errors->has('vendor_street')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_street')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" name="vendor_city" class="form-control form-control-sm" id="vendor_city" placeholder="City Name">
                                <?php if($errors->has('vendor_city')): ?>
                                <p class="text-danger"><?php echo e($errors->first('vendor_city')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#vendor_description').summernote({
            height: 100,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/vendor/create.blade.php ENDPATH**/ ?>