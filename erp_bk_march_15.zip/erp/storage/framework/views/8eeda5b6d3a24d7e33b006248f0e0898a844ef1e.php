
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Production Create</h3>
                    <a href="<?php echo e(route('production.master.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Production list</a>
                </div>
            </div>
            <div class="card-body">
            <form action="<?php echo e(route('production.master.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                        <table class="table table-bordered" width="100%">
                            <thead>
                                <tr>
                                    <th>Batch Number</th>
                                    <th>Item Name</th>
                                    <th>Production Date</th>
                                    <th>qty</th>
                                    <th>Price</th>
                                    <th>Total Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($getItem): ?>
                                <tr>
                                    <?php
                                    $production_id = \App\Models\ProductionMaster::latest()->first();
                                    if($production_id){
                                    $batch_number = 'MPBN-'.'0'.$production_id->id;
                                    }else{
                                    $batch_number = 'MPBN-'.'01';
                                    }
                                    ?>
                                    <td width="15%">
                                   
                                    <input type="text" class="form-control form-control-sm" name="batch_number" value="<?php echo e($batch_number); ?>">
                                    </td>
                                    <td width="25%">
                                    <input type="text" class="form-control form-control-sm" value="<?php echo e($getItem->item_name); ?>">
                                    </td>
                                    <input type="hidden" name="item_id" value="<?php echo e($getItem->id); ?>">
                                    <td width="15%"><input type="date" class="form-control form-control-sm" name="production_date" value="<?php echo e(date('Y-m-d')); ?>">
                                    <?php if($errors->has('production_date')): ?>
                                <p class="text-danger"><?php echo e($errors->first('production_date')); ?> </p>
                                <?php endif; ?>
                                </td>
                                    <td width="10%"><input type="text" class="form-control form-control-sm prod_qty" name="prod_qty" id="prod_qty"></td>
                                    <td width="15%"><input type="number" class="form-control form-control-sm" name="item_price" id="item_price" value="<?php echo e($getItem->item_price); ?>" readonly></td>
                                    <td width="15%"><input class="form-control form-control-sm" type="text" id="total_price" readonly></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-12">
                    <?php if($getItemRm): ?>
                        <table class="table table-bordered text-center" id="tableContent">

                            <thead>
                                <tr>
                                    <th>RM Name</th>
                                    <th>RM Qty</th>
                                    <th>Rm Unit</th>
                                    <th>RM Price</th>
                                    <th>Wastage</th>
                                    <th>Total_rm_qty</th>
                                    <th>Total Wastage</th>
                                </tr>
                            </thead>
                            <tbody>
                              
                                <?php $__currentLoopData = $getItemRm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rmItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="itemrow">
                                    <input type="hidden" name="rm_item_id[]" value="<?php echo e($rmItem->used_item_id); ?>">
                                    <td width="30%"><input type="text" class="form-control form-control-sm" value="<?php echo e(\App\Models\Items::where('id',$rmItem->used_item_id)->value('item_name')); ?>"></td>
                                    <td width="10%">
                                    <input type="number" name="rm_item_qty[]" id="rm_item_qty" class="form-control form-control-sm rm_item_qty" value="<?php echo e($rmItem->used_item_qty); ?>" readonly>  
                                    </td>
                                    <td><input type="text" class="form-control form-control-sm" value=" <?php echo e($rmItem->used_item_unit); ?>"></td>
                                    <td>
                                    <input type="text" name="rm_item_price[]" id="rm_item_price" class="form-control form-control-sm" value="<?php echo e(\App\Models\Items::where('id',$rmItem->used_item_id)->value('item_price')); ?>" readonly> 
                                    </td>
                                    <td width="10%"><input type="text" name="wastage_quantity[]" id="wastage_quantity" class="form-control form-control-sm wastage_quantity" value="<?php echo e($rmItem->wastage_quantity); ?>"></td>

                                    <td width="15%"><input type="text" id="total_rm_qty" class="form-control form-control-sm total_rm_qty" value="" readonly></td>

                                    <td width="15%"><input type="text" id="total_wastage_qty" class="form-control form-control-sm" value="" readonly></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                            </tbody>

                        </table>
                        <?php else: ?>
                        <p>This Product has no bill of material</p>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-success btn-sm">Save</button>
                    </div>
                    
                </div>
            </div>
            </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#vendor_description').summernote({
            height: 100,
        });
    });
</script> -->
<!-- <script src="<?php echo e(asset('backend/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/handlebars.min.js')); ?>"></script> -->
<!--Select2 support-->
<link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/select2/css/select2.min.css">
<script src="<?php echo e(asset('backend')); ?>/plugins/select2/js/select2.min.js"></script>
<!--Select2 cdn support-->
<!-- <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> -->

<script type="text/javascript">
    $(".select2").select2();
</script>

<script type="text/javascript">
$(function(){
    $(document).on("keyup","#prod_qty",function(){
        var prod_qty = $(this).val();
        var item_price = $("#item_price").val();
        var total_price = prod_qty * item_price;
        $("#total_price").val(total_price);
    });
});
$(document).on("keyup","#item_price",function(){
        var item_price = $(this).val();
        var prod_qty = $("#prod_qty").val();
        var total_price = prod_qty * item_price;
        $("#total_price").val(total_price);
    });
// $("#alldata").keyup(function() {
// var share = this.value;
//  $('tr.itemrow').each(function () {
//   $(this).find('.price1').each(function(){
//    var tdval = $(this).text();
//    $(".result").text(share * tdval);
//   });     
//  });
// });

$(function(){
    $(document).on("keyup","#prod_qty",function(){
        // var prod_qty = $(this).val();
            $('tr.itemrow').each(function () {
                $(this).find('.rm_item_qty').each(function(){
                    var rm_qty = $(this).val();
                    var prod_qty = $('#prod_qty').val();
                    var total_rm = prod_qty * rm_qty;
                     alert(total_rm);
                    $(".total_rm_qty").val(total_rm);
                }); 

                // var rm_qty =  $('#rm_item_qty').val()
                // var rm_wastage =  $('#wastage_quantity').val()
                // var total_rm = parseFloat(rm_qty) + parseFloat(rm_wastage);
                // var total_rm_qty = prod_qty * total_rm;
                // var total_wastage_qty = prod_qty * rm_wastage;
                // $("#total_rm_qty").val(total_rm_qty);
                // $("#total_wastage_qty").val(total_wastage_qty);
        });       
    });
    // $(document).on("keyup","#wastage_quantity",function(){
    //     var rm_wastage = $(this).val();
    //         $("#tableContent tbody").each(function () {
    //             var rm_qty =  $('#rm_item_qty').val();
    //             var rm_price =  $('#rm_item_price').val();
    //             var prod_qty =  $('#prod_qty').val();
    //             var total_rm = parseFloat(rm_qty) + parseFloat(rm_wastage);
    //             var total_rm_qty = prod_qty * total_rm;
    //             var total_wastage_qty = prod_qty * rm_wastage;
    //             $("#total_rm_qty").val(total_rm_qty);
    //             $("#total_wastage_qty").val(total_wastage_qty);
                
    //     });       
    // });
 

});
//rm used
// $(function(){
//     $(document).on("keyup","#rm_item_qty",function(){
//         var rm_item_qty = $(this).val();
//         var rm_item_price = $("#rm_item_price").val();
//         var rm_total_price = rm_item_qty * rm_item_price;
//         $("#rm_total_price").val(rm_total_price);
//     });
// });
// $(function(){
//     $(document).on("keyup","#rm_item_price",function(){
//         var rm_item_price = $(this).val();
//         var rm_item_qty = $("#rm_item_qty").val();
//         var rm_total_price = rm_item_qty * rm_item_price;
//         $("#rm_total_price").val(rm_total_price);
//     });
// });


$(document).ready(function() {
    $(document).on('change',"#item_id",function(){
        var item_id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });     
       $.ajax({
            type:"GET",
            url:"<?php echo e(route('rm.item.info')); ?>",
            data:{
                'item_id' :item_id,
            },
            dataType: "json",
            success:function(response){
                $('#rm_item_name').val(response.rm_item_name.item_name);
                $('#rm_item_id').val(response.rm_item_info.used_item_id);
                $('#rm_item_qty').val(response.rm_item_info.used_item_qty);
            }
       });
       });

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/production-master/create.blade.php ENDPATH**/ ?>