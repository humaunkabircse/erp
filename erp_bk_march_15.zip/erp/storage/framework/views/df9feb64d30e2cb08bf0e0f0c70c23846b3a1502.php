
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-lg-8 col-md-8  offset-md-2 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Expences Category Edit</h3>
                    <a href="<?php echo e(route('expenses.category.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Expences Category list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('expenses.category.update',$expencesCategory->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body" style="background:#F7F7F7">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Expenses Category Name</label>
                            <input type="text" class="form-control" name="expenses_cat_name" value="<?php echo e($expencesCategory->expenses_cat_name); ?>"/>
                            <?php if($errors->has('expenses_cat_name')): ?>
                            <p class="text-danger"><?php echo e($errors->first('expenses_cat_name')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                      
                            <div class="form-group">
                                <label for="">Expenses Category Note</label>
                                <textarea rows="5" name="expenses_cat_note" class="form-control form-control-sm">
                                <?php echo e($expencesCategory->expenses_cat_note); ?>

                                </textarea>
                                <?php if($errors->has('expenses_cat_note')): ?>
                                <p class="text-danger"><?php echo e($errors->first('expenses_cat_note')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                     <button type="submit" class="btn btn-primary btn-block">Update</button>
                    </div>          
                    
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/expences-category/edit.blade.php ENDPATH**/ ?>