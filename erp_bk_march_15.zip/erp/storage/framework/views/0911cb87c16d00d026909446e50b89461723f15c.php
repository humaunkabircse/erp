
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Payment Mode Edit</h3>
                    <a href="<?php echo e(route('payment.mode.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Payment Mode list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('payment.mode.update',$paymentMode->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Payment Mode</label>
                            <input type="text" class="form-control form-control-sm" name="pay_mode" value="<?php echo e($paymentMode->pay_mode); ?>"/>
                            <?php if($errors->has('pay_mode')): ?>
                            <p class="text-danger"><?php echo e($errors->first('pay_mode')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                        <label for="">Payment Number</label>
                            <input type="text" class="form-control form-control-sm" name="pay_number" value="<?php echo e($paymentMode->pay_number); ?>"/>
                            <?php if($errors->has('pay_number')): ?>
                            <p class="text-danger"><?php echo e($errors->first('pay_number')); ?> </p>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-12">
                      
                            <div class="form-group">
                                <label for="">Payment Note</label>
                                <textarea rows="9" name="pay_note" class="form-control form-control-sm">
                                <?php echo e($paymentMode->pay_note); ?>

                                </textarea>
                                <?php if($errors->has('pay_note')): ?>
                                <p class="text-danger"><?php echo e($errors->first('pay_note')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                     <div class="row">
                     <div class="col-lg-12 col-md-12 col-12">
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control" name="status">
                                    <option value="active" <?php echo e($paymentMode->status=='active'?'selected' : ''); ?>>
                                        Active</option>
                                    <option value="inactive" <?php echo e($paymentMode->status=='inactive'?'selected' : ''); ?>>
                                        Inactive
                                    </option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                <p class="text-danger"><?php echo e($errors->first('status')); ?> </p>
                                <?php endif; ?>
                            </div>                            
                        </div>
                     </div>
                     <button type="submit" class="btn btn-primary">Update</button>
                    </div>          
                    
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/payment-mode/edit.blade.php ENDPATH**/ ?>