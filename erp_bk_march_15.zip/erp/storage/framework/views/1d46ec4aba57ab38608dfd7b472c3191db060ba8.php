
<?php $__env->startSection('style'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css">
<style>
    table tr {
        height: 19px !important
    }

    .myTable {
        background: #333;
        padding: 5px 15px;
        border: 1px solid #333;
        border-radius: 10px;
        text-align: center;
        color: #fff;
        margin-left:10px;
    }


table tr{
    line-height: 0.5;  
}

</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="col-md-8 offset-md-2">
    <!-- <a href="<?php echo e(route('invoice.pdf',$invoiceMasterInfo->id)); ?>" type="button" class="btn btn-outline-warning btn-sm">Export to Pdf</a> -->
    <div class="row">
        <div class="col-md-2 col-12">
            <div class="navbar-brand">
                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('backend')); ?>/assets/images/logo.png" alt="" width="120px" height="50px"></a>
            </div>
        </div>
        <div class="col-md-8 col-12">
            <h5 class="text-center">MITHEN PLASTIC INDUSTRIES</h5>
            <p class="text-center">Vill: Bevage, Post: Baruipara, Mirpur, Kushtia <br> Email: Mehbuba@methanplastic.com, <br> Web: www.methanplastic.com<br> Cell: +8801955-462558</p>
        </div>
        <div class="col-md-2 col-12">

        </div>
    </div>

    <div class="row">
        <div class="col-md-5">
            <table class="table table-bordered text-center">
                <tr>
                    <th>Invoice No</th>
                    <td><?php echo e($invoiceMasterInfo->invoice_number); ?></td>
                </tr>
                <tr>
                    <th>Invoice Date</th>
                    <td><?php echo e(date('d-m-Y', strtotime($invoiceMasterInfo->invoice_date))); ?></td>
                </tr>
                <tr>
                    <th>PWD NO</th>
                    <td></td>
                </tr>

            </table>
        </div>
        <div class="col-md-2">
            <span class="myTable">Bill</span>
        </div>
        <div class="col-md-5">
            <table class="table table-bordered text-center">
                <tr>
                    <th style="width:50%">Bill No</th>
                    <td></td>
                </tr>
                <tr>
                    <th style="width:50%">Bill Date</th>
                    <td></td>
                </tr>
                <tr>
                    <th style="width:50%">PWD NO</th>
                    <td></td>
                </tr>

            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 col-12">

            <p>Name/company: <?php echo e($customerinfo->name); ?></p>


            <p>Address: <?php echo e($customerinfo->street); ?>,<?php echo e($customerinfo->city); ?>,<?php echo e($customerinfo->district); ?>,<?php echo e($customerinfo->zip); ?>,<?php echo e($customerinfo->country); ?></p>

        </div>
    </div>
    <div class="row">
        <div class="col-md-12 col-12">
            <table class="table table-bordered text-center">
                <tr>
                    <th>SL#</th>
                    <th>Description</th>
                    <th>Quantity(Pcs)</th>
                    <th>Unit Price</th>
                    <th>Total Price(Taka)</th>
                </tr>
               
                <?php $__currentLoopData = $invoiceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->item_name); ?></td>
                    <td><?php echo e($item->item_qty); ?></td>
                    <td><?php echo e($item->item_price); ?></td>
                    <td class="force"><?php echo e($item->item_qty * $item->item_price); ?></td>
                   
                </tr>
               
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td colspan="4">Subtotal:</td>
                    <td id="total_forces"></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-md-12 col-12">
            In Word (Taka) ----------------------------------------------------------------------------
        </div>
    </div>
    <div class="row mt-5 pt-3">
        <div class="col-md-3 col-12" style="font-size:12px">
            <p>Received By</p>
        </div>
        <div class="col-md-3 col-12" style="font-size:12px">
        <p>Prepared By</p> 
        </div>
        <div class="col-md-3 col-12" style="font-size:12px">
        <p>Recommended</p>
        </div>
        <div class="col-md-3 col-12" style="font-size:12px">
        <p>Authorised Signature</p>
        </div>
    </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#myTable').DataTable({
            scrollY: 370,
            scrollX: true,
            scroller: true,
        });
    });
</script>
<script>
    $(function() {
        var a = 0;
        $('.force').each(function() {
            a += parseInt($(this).text());
        });
        $('#total_forces').text(a);
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/invoice-master/invoice-view.blade.php ENDPATH**/ ?>