<?php $__env->startSection('style'); ?>
<style>
    table tr {
        height: 19px !important
    }

    .myTable {
        background: #333;
        padding: 5px 15px;
        border: 1px solid #333;
        border-radius: 10px;
        text-align: center;
        color: #fff;
        margin-left:10px;
    }


table tr{
    line-height: 0.5;  
}

</style>
</style>
<!-- DataTables -->
<!-- <link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css"> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
  <div class="col-lg-12 col-md-12 col-12">
    <?php if(empty($receiveDetails)): ?>
    <form action="<?php echo e(route('received.search')); ?>" method="POST">
          <?php echo csrf_field(); ?>
  <div class="form-row align-items-center">
    <div class="col-sm-3 my-1">
    <label>Vendor</label>
            <select class="form-control" name="vendor_id" id="vendor_id">
              <option selected disabled>Select Vendor</option>
              <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($vendor->id); ?>">
                <?php echo e($vendor->vendor_company); ?>

              </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>
    <div class="col-sm-3 my-1">
    <label for="exampleInputEmail1">Start Date</label>
            <input type="date" name="start_date" class="form-control" id="exampleInputEmail1" value="<?php echo e(date('Y-m-d')); ?>">
    </div>
    <div class="col-sm-3 my-1">
    <label for="exampleInputEmail1">End Date</label>
            <input type="date" name="end_date" class="form-control" id="exampleInputEmail1" value="<?php echo e(date('Y-m-d')); ?>">
    </div>
    <div class="col-auto my-1">
    <button type="submit" class="btn btn-warning">Search</button>
    </div>
  </div>
</form>
      <?php endif; ?>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12 col-md-12 col-12">    
      <?php if(!empty($receiveDetails)): ?>
      <div class="card">
        <div class="card-header d-flex justify-content-between">
          <div>
          <h4>Received Report</h4>
          Date:
          <?php $__currentLoopData = $dateRange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e(date('d/m/Y', strtotime($date))); ?>

          <?php if( ! $loop->last): ?>- <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div>
          <a href="<?php echo e(route('received.print',['vendor_id'=>$vendor_id,'start_date'=>$start_date,'end_date'=>$end_date])); ?>" class="btn btn-primary btn-sm btnprint">Print Preview</a>
          </div>
          <!-- <form action="<?php echo e(route('received.print')); ?>" method="POST">
          <?php echo csrf_field(); ?>
  <div class="form-row align-items-center">
    <div class="col-sm-3 my-1">
    <input type="hidden" name="vendor_id" class="form-control" id="vendor_id" value="<?php echo e($vendor_id); ?>">
    </div>
    <div class="col-sm-3 my-1">
            <input type="hidden" name="start_date" class="form-control" id="start_date" value="<?php echo e($start_date); ?>">
    </div>
    <div class="col-sm-3 my-1">
            <input type="hidden" name="end_date" class="form-control" id="end_date" value="<?php echo e($end_date); ?>">
    </div>
    <div class="col-auto my-1">
    <button type="submit" class="btn btn-warning btnprint">Print</button>
    </div>
  </div>
</form> -->
        </div>
       
        <div class="card-body">
          <table class="display table-bordered table-striped text-center" style="border-color:white;font-size:12px;" width="100%">
            <thead>
              <tr style="background:#395697;color:#fff;font-size:11px;">
                <th>SL#</th>
                <th>Vendor</th>
                <th>Received Date</th>
                <th>Received Ref</th>
                <th>Total Qty</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $receiveDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->vendor_company); ?></td>
                <td><?php echo e($item->rec_date); ?></td>
                <td><?php echo e($item->rec_by); ?></td>
                <td><?php echo e($item->item_qty); ?></td>
                <td><?php echo e($item->item_price); ?></td>
              </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody>
          </table>
        </div>
      </div>
<?php else: ?>
<p class="text-center">Report Display after search</p>
<?php endif; ?>


    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- <script src="<?php echo e(asset('backend/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script> -->
<script>
$(document).ready(function() {
      jQuery('.btnprint').printPage();

    });
</script>
<!-- <script type="text/javascript">
  $(document).ready(function() {
    $('#myTable').DataTable({
      scrollY: 370,
      scrollX: true,
      scroller: true,
    });
  });
</script>

<link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/select2/css/select2.min.css">
<script src="<?php echo e(asset('backend')); ?>/plugins/select2/js/select2.min.js"></script>

<script type="text/javascript">
  $(".select2").select2();
</script> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/reports/received/received-report.blade.php ENDPATH**/ ?>