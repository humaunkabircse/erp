<?php $__env->startSection('style'); ?>
<style>
    .report-item {
        height: 80px;
        width: 200px;
        background-color: red;
        padding-top: 30px;
        text-align: center;
        font-size: 18px;
    }

    .report-item a {
        color: #fff
    }

</style>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div>
                        <h4>Bill Details</h4>
                    </div>
                    <div>
                    <a href="<?php echo e(route('bill.print',$id)); ?>" class="btn btn-warning btn-sm btnprint"><i class="fa fa-print" aria-hidden="true"></i></a>
                    </div>
                  
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-5 col-12">

                        <table class="table table-bordered text-center">                          
                            <tr>
                                <th style="width:30%">Invoice No:</th>
                                <td style="width:35%;text-align:left"><?php echo e($invoice->invoice_number); ?></td>
                            </tr>
                            <tr>
                                <th style="width:30%">Invoice Date:</th>
                                <td style="width:35%;text-align:left">
                                    <?php echo e(date('d-m-Y', strtotime($invoice->invoice_date))); ?></td>
                            </tr>
                        </table>
                        </div>
                        <div class="col-md-2 col-12">
                                <p class="text-center bg-dark p-2 mt-4 text-white">Bill</p>
                        </div>
                        <div class="col-md-5 col-12">

                        <table class="table table-bordered text-center"> 
                            <tr style="width:25%">
                                <th style="width:30%">BIll No:</th>
                                <td style="width:70%;text-align:left" colspan="2"><?php echo e($billMasterInfo->bill_number); ?></td>
                            </tr>
                            <tr>
                                <th style="width:30%">Bill Date:</th>
                                <td style="width:35%;text-align:left">
                                    <?php echo e(date('d-m-Y', strtotime($billMasterInfo->bill_date))); ?></td>
                            </tr>
                        </table>
                        </div>
                    </div>
                    <div class="col-md-12 col-12">
                    <p class="mb-3">Name/Company :<?php echo e($customerinfo->cus_company); ?></p>
                    <p>Address: <?php echo e($customerinfo->district); ?>, <?php echo e($customerinfo->country); ?></p>
                    </div>
                    <table class="display table-bordered table-striped text-center"
                        style="border-color:white;font-size:12px;" width="100%">
                        <thead>
                            <tr style="background:#395697;color:#fff;font-size:11px;">
                                <th>SL#</th>
                                <th>Item Name</th>
                                <th>Item Qty</th>
                                <th>Unit Price</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $total_amount=0;
                            ?>
                            <?php $__currentLoopData = $billDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->item_name); ?></td>
                                <td><?php echo e($item->item_qty); ?></td>
                                <td><?php echo e($item->item_price); ?></td>
                                <td><?php echo e($item->item_qty * $item->item_price); ?></td>
                            </tr>
                            <?php
                            $total_amount +=$item->item_qty * $item->item_price
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Total:</td>
                                <td><?php echo e($total_amount); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<!-- <script src="<?php echo e(asset('backend/assets/js/jquery-3.5.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script> -->
<script type="text/javascript">
    $(document).ready(function () {
        $('#myTable').DataTable({
            scrollY: 370,
            scrollX: true,
            scroller: true,
        });
    });

</script>
<!--Select2 support-->
<!-- <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/plugins/select2/css/select2.min.css">
<script src="<?php echo e(asset('backend')); ?>/plugins/select2/js/select2.min.js"></script> -->
<!--Select2 cdn support-->
<!-- <script type="text/javascript">
    $(".select2").select2();

</script> -->
<script>
    $(document).ready(function () {
        jQuery('.btnprint').printPage();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/bill-master/bill-preview.blade.php ENDPATH**/ ?>