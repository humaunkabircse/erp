
<?php $__env->startSection('style'); ?>
 <!-- DataTables -->
 <link rel="stylesheet" href="<?php echo e(asset('backend/datatable/css')); ?>/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> <?php echo e(session('status')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>       
        <?php endif; ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4>Stock Adjustment List</h4>
                    <a type="button" class="btn btn-primary float-end" href="<?php echo e(route('stock.adjustment.create')); ?>"><i class="fas fa-plus-circle"></i> Add New</a>
                    
                </div>
                <div class="card-body" style="overflow-x:scroll">
                <table id="myTable" class="display table-bordered table-striped text-center" style="border-color:white;font-size:12px;" width="100%">
                        <thead>
                            <tr style="background:#395697;color:#fff;font-size:12px;">
                                <th>SL#</th>
                                <th>Adjustment Number</th>
                                <th>Item Name</th>
                                <th>Adjustment Addition Qty</th>
                                <th>Adjustment Subtraction Qty</th>
                                <th>Action</th>
                            </tr>
                        </thead>
						<tbody> 
                        <?php $__currentLoopData = $stockAdjustments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->stock_adjustment_Number); ?></td> 
                                <td><?php echo e(\App\Models\Items::where('id',$item->item_id)->value('item_name')); ?></td>
                                <td><?php echo e($item->stock_adjustment_addition_qty); ?></td>
                                <td><?php echo e($item->stock_adjustment_subtraction_qty); ?></td>
                                <td>
                                <a href="<?php echo e(route('stock.adjustment.edit',$item->id)); ?>" type="button" class="btn btn-outline-primary btn-sm"><i class="fas fa-edit"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
                       </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('backend/datatable/js')); ?>/jquery.dataTables.min.js"></script>
<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable({
      scrollY:     370,
      scrollX:     true,
      scroller:    true,
    });
} );
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/methanplastic.com/public_html/erp/resources/views/pages/stock-adjustment/index.blade.php ENDPATH**/ ?>