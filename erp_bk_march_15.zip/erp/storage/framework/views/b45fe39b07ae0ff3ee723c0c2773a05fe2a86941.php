
<?php $__env->startSection('style'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 col-md-12 col-12">
        <div class="card card-primary">
            <div class="card-header">

                <div class="d-flex justify-content-between">
                    <h3 class="card-title">Item Edit</h3>
                    <a href="<?php echo e(route('items.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-angle-double-left" aria-hidden="true"></i> Item list</a>
                </div>
            </div>
            <!-- /.card-header -->

            <!-- form start -->
            <form action="<?php echo e(route('items.update',$editItem->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Name</label>
                                <input type="text" name="item_name" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e($editItem->item_name); ?>" placeholder="Enter Name">
                                <?php if($errors->has('item_name')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_name')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea rows="5" name="item_desc" class="form-control form-control-sm" placeholder="Write description hare..">
                                <?php echo e($editItem->item_desc); ?>

                                </textarea>
                                <?php if($errors->has('item_desc')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_desc')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">item Price</label>
                                <input type="number" name="item_price" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e($editItem->item_price); ?>" placeholder="Enter Price">
                                <?php if($errors->has('item_price')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_price')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Item Last Purchase Price :</label>
                                <p id=last_perch_price></p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">item Tax</label>
                                <input type="number" name="item_tax" class="form-control form-control-sm" id="exampleInputEmail1" value="<?php echo e($editItem->item_tax); ?>" placeholder="Enter Tax">
                                <?php if($errors->has('item_tax')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_tax')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Item Vendor</label>
                                <select class="form-control form-control-sm" name="item_vendor">
                                    <option selected disabled> Select vendor</option>
                                <?php $__currentLoopData = \App\Models\Vendor::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vendor->id); ?>" <?php echo e($editItem->item_vendor==$vendor->id ?'selected':''); ?>><?php echo e($vendor->vendor_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('item_vendor')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_vendor')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Category</label>
                                <select id="cat_id" class="form-control form-control-sm" name="cat_id">
                                <option selected disabled>--select category--</option>
                                <?php $__currentLoopData = \App\Models\Category::where('is_parent','1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php echo e($editItem->cat_id == $cat->id ?'selected':''); ?>><?php echo e($cat->item_cat_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                                <div class="form-group d-none" id="child_cat_div">
                                    <label>Child Category</label>
                                    <select id="child_cat_id" class="form-control form-control-sm" name="child_cat_id">
                                    <!-- <option selected disabled>Select child category</option> -->
                                    
                                    </select>
                                </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-12">
                        <div class="form-group">
                                <label>Item Unit</label>
                                <select class="form-control form-control-sm" name="item_unit">
                                    <option selected disabled> Select item unit</option>
                                    <?php $__currentLoopData = \App\Models\ItemUnit::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->id); ?>" <?php echo e($editItem->item_unit == $unit->id ?'selected':''); ?>> <?php echo e($unit->unit_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('item_unit')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_unit')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Item Group</label>
                                <select class="form-control form-control-sm" name="item_group">
                                    <option selected disabled> Select item group</option>
                                    <?php $__currentLoopData = \App\Models\ItemGroup::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group->id); ?>" <?php echo e($editItem->item_group == $group->id ?'selected':''); ?>><?php echo e($group->item_group_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('item_group')): ?>
                                <p class="text-danger"><?php echo e($errors->first('item_group')); ?> </p>
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group">
                                <label>Terms & Condition</label>
                                <select class="form-control form-control-sm" name="terms_and_conditions">
                                    <option selected disabled> Select terms and conditions</option>
                                    <?php $__currentLoopData = \App\Models\Terms::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($term->id); ?>" <?php echo e($editItem->terms_and_conditions == $term->id ?'selected':''); ?>><?php echo e($term->term_desc); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('terms_and_conditions')): ?>
                                <p class="text-danger"><?php echo e($errors->first('terms_and_conditions')); ?> </p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>Status</label>
                                <select class="form-control form-control-sm" name="status">
                                    <option value="active" <?php echo e($editItem->status=='active'?'selected' : ''); ?>>
                                        Active</option>
                                    <option value="inactive" <?php echo e($editItem->status=='inactive'?'selected' : ''); ?>>
                                        Inactive
                                    </option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                <p class="text-danger"><?php echo e($errors->first('status')); ?> </p>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                    <button type="submit" class="btn btn-primary">Update Item</button>
                </div>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#vendor_description').summernote({
            height: 100,
        });
    });
</script>

<script>
  var child_cat_id = <?php echo e($editItem->child_cat_id); ?>;

  $('#cat_id').change(function(){
    var cat_id = $(this).val();
    // alert(cat_id);
    if(cat_id != null){
      $.ajax({
        url:"<?php echo e(route('category.child')); ?>",
        type:"POST",
        data:{
            _token:'<?php echo e(csrf_token()); ?>',
            id:cat_id,
        },
        // dataType: 'JSON',
        // contentType: false,
        // cache: false,
        // processData: false,
        success:function(response){
          var html_option = "<option value=''>--child Category--</option>";
          if(response.status){
            $('#child_cat_div').removeClass('d-none');
            $.each(response.data,function(id,item_cat_name){
                html_option += "<option value='"+id+"' "+(child_cat_id==id?'selected':'')+">"+item_cat_name+"</option>";
            });
          }else{
            $('#child_cat_div').addClass('d-none');
          }
          $('#child_cat_id').html(html_option);
        }

      });
    }
  });
if(child_cat_id !=null){
  $('#cat_id').change();
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\r_inventory\resources\views/pages/items/edit.blade.php ENDPATH**/ ?>